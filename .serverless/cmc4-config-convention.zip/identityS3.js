"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _ = require("lodash");
/**
 * Create new entities in the S3 bucket stored to a numeric key based location in an S3 bucket.
 * Autoincrements the identifier to the next available numeric S3 key.
 * Will add the identifier to the entity data.
 *
 * @export
 * @class IdentityS3Post
 */
var IdentityS3Post = /** @class */ (function () {
    /**
     * Creates an instance of IdentityS3Post.
     * @param {*} entity Json data of the entity to store
     * @param {S3Service} s3Service S3 Service
     * @param {string} prefix Prefix or folder path to store entities, must include trailing delimiter
     * @param {string} extension File extension to store entities, i.e. '.json'
     * @param {string} identityKey Identity will be stored to this location on the entity data
     * @param {*} [metadata] Optional, metadata that will be stored on the file at S3
     * @memberof IdentityS3Post
     */
    function IdentityS3Post(entity, s3Service, prefix, extension, identityKey, metadata) {
        if (!s3Service) {
            throw "Invalid s3Service.";
        }
        if (!extension) {
            throw "Invalid extension.";
        }
        if (!entity) {
            throw "Invalid entity.";
        }
        this._s3Service = s3Service;
        this._prefix = prefix;
        this._extension = extension;
        this._identityKey = identityKey;
        this._entity = entity;
        this._metadata = metadata;
    }
    /**
     * Execute the post command on S3
     *
     * @returns {Promise<any>}
     * @memberof IdentityS3Post
     */
    IdentityS3Post.prototype.post = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            //determine next id
            _this._s3Service.listObjectNames(_this._prefix).then(function (files) {
                //remove extension and prefix, order by numeric desc
                var highestId = _(files)
                    .map(function (f) { return parseInt(f.substring(_this._prefix.length)); })
                    .filter(function (f) { return f; })
                    .orderBy(function (f) { return f; }, 'desc')
                    .head();
                var nextId = (highestId || 0) + 1;
                console.log("nextId:[" + nextId + "]");
                //add id to json entity
                if (_this._identityKey) {
                    _this._entity[_this._identityKey] = nextId;
                }
                //persist entity
                _this._s3Service.putObject(nextId + _this._extension, JSON.stringify(_this._entity), _this._prefix, _this._metadata)
                    .then(function (resolved) { resolve(); }, function (rejected) { reject(rejected); });
            }, function (rejected) { reject(rejected); });
        });
    };
    return IdentityS3Post;
}());
exports.IdentityS3Post = IdentityS3Post;
/**
 * Replace entity at specified id location with new data.
 *
 * @export
 * @class IdentityS3Put
 */
var IdentityS3Put = /** @class */ (function () {
    /**
     * Creates an instance of IdentityS3Put.
     * @param {number} id
     * @param {*} entity Json data of the entity to store
     * @param {S3Service} s3Service S3 Service
     * @param {string} prefix Prefix or folder path to store entities, must include trailing delimiter
     * @param {string} extension File extension to store entities, i.e. '.json'
     * @param {string} identityKey Identity will be stored to this location on the entity data
     * @param {*} [metadata] Optional, metadata that will be stored on the file at S3
     * @memberof IdentityS3Put
     */
    function IdentityS3Put(id, entity, s3Service, prefix, extension, identityKey, metadata) {
        if (!s3Service) {
            throw "Invalid s3Service.";
        }
        if (!extension) {
            throw "Invalid extension.";
        }
        if (!id || id <= 1) {
            throw "Id must be greater than 0.";
        }
        if (!entity) {
            throw "Invalid entity.";
        }
        if (identityKey && id != entity[identityKey]) {
            throw "Provided Id [" + id + "] does not match identity key on entity [" + entity[identityKey] + "].";
        }
        this._s3Service = s3Service;
        this._prefix = prefix;
        this._extension = extension;
        this._identityKey = identityKey;
        this._id = id;
        this._entity = entity;
        this._metadata = metadata;
    }
    /**
     * Execute the put command on S3
     *
     * @returns {Promise<any>}
     * @memberof IdentityS3Put
     */
    IdentityS3Put.prototype.put = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var s3Key = _this._id + _this._extension;
            //confirm s3 key exists
            _this._s3Service.exists(s3Key, _this._prefix).then(function (exists) {
                if (!exists) {
                    reject("S3 key [" + s3Key + "] not found.");
                }
                //persist entity
                _this._s3Service.putObject(s3Key, JSON.stringify(_this._entity), _this._prefix, _this._metadata)
                    .then(function (resolved) { resolve(); }, function (rejected) { reject(rejected); });
            }, function (rejected) { reject(rejected); });
        });
    };
    return IdentityS3Put;
}());
exports.IdentityS3Put = IdentityS3Put;
//# sourceMappingURL=identityS3.js.map