"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AWS = require("aws-sdk");
var _ = require("lodash");
/**
 * wrapper for aws s3 that support Promises
 *
 * @export
 * @class S3Service
 */
var S3Service = /** @class */ (function () {
    function S3Service(s3Bucket) {
        if (!s3Bucket) {
            throw "Invalid S3 Bucket";
        }
        this._s3Bucket = s3Bucket;
    }
    S3Service.prototype.listObjectNames = function (prefix) {
        var _this = this;
        var maxKeys = 2147483647;
        var delimiter = '/';
        return new Promise(function (resolve, reject) {
            try {
                var files_1 = [];
                var f_1 = function (data) {
                    var _this = this;
                    files_1 = files_1.concat(_.map(data.Contents, 'Key'));
                    if (data.IsTruncated) {
                        this._s3.listObjectsV2({
                            Bucket: this._s3Bucket,
                            MaxKeys: maxKeys,
                            Delimiter: delimiter,
                            Prefix: prefix,
                            ContinuationToken: data.NextContinuationToken
                        }, function (err, data) {
                            if (err) {
                                reject("Error calling listObjectsV2 on S3. Error: " + err);
                            }
                            else {
                                f_1.call(_this, data);
                            }
                        });
                    }
                    else {
                        resolve(files_1);
                    }
                };
                _this._connect();
                _this._s3.listObjectsV2({
                    Bucket: _this._s3Bucket,
                    MaxKeys: maxKeys,
                    Delimiter: delimiter,
                    Prefix: prefix,
                    StartAfter: prefix
                }, function (err, data) {
                    if (err) {
                        reject("Error calling listObjectsV2 on S3. Error: " + err);
                    }
                    else {
                        f_1.call(_this, data);
                    }
                });
            }
            catch (e) {
                reject("Exception occurred in S3Service::listObjectNames(): " + e);
            }
        });
    };
    S3Service.prototype.exists = function (key, prefix) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            try {
                _this._connect();
                _this._s3.headObject({
                    Bucket: _this._s3Bucket,
                    Key: (prefix || '') + key,
                }, function (err, data) {
                    if (err) {
                        resolve(false);
                    }
                    else {
                        resolve(true);
                    }
                });
            }
            catch (e) {
                reject("Exception occurred in S3Service::exists(): " + e);
            }
        });
    };
    S3Service.prototype.putObject = function (key, body, prefix, metadata) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            try {
                _this._connect();
                _this._s3.putObject({
                    Bucket: _this._s3Bucket,
                    Body: body,
                    Key: (prefix || '') + key,
                    Metadata: (metadata || null)
                }, function (err, data) {
                    if (err) {
                        reject("Error calling putObject on S3. Error: " + err);
                    }
                    else {
                        resolve();
                    }
                });
            }
            catch (e) {
                reject("Exception occurred in S3Service::putObject(): " + e);
            }
        });
    };
    S3Service.prototype._connect = function () {
        if (!this._s3) {
            this._s3 = new AWS.S3({ params: { Bucket: this._s3Bucket } });
        }
    };
    return S3Service;
}());
exports.S3Service = S3Service;
//# sourceMappingURL=s3Service.js.map